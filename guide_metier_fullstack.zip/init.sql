-- init.sql: create reviews table
CREATE TABLE IF NOT EXISTS reviews (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  overall INTEGER,
  comment TEXT,
  progress INTEGER,
  quality INTEGER,
  teamwork INTEGER,
  presentation INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
