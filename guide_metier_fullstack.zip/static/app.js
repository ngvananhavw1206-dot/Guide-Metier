(function(){
  const apiBase = '/api';
  const ratings = ["progress","quality","teamwork","presentation"];
  const defaultStars = 4;

  document.querySelectorAll('.rating').forEach(node=>{
    const name = node.dataset.name;
    for(let i=1;i<=5;i++){
      const btn = document.createElement('button');
      btn.type = "button";
      btn.setAttribute('aria-label', name + ' ' + i);
      btn.dataset.value = i;
      btn.textContent = i;
      btn.addEventListener('click', ()=> setRating(name, i));
      node.appendChild(btn);
    }
  });
  function setRating(name, value){
    const node = document.querySelector('.rating[data-name="'+name+'"]');
    node.querySelectorAll('button').forEach(b=>{
      b.classList.toggle('active', Number(b.dataset.value) <= value);
    });
    node.dataset.current = value;
  }
  ratings.forEach(r=> setRating(r, defaultStars));
  const overall = document.getElementById('overall');
  const overallVal = document.getElementById('overallVal');
  overall.addEventListener('input', ()=> overallVal.textContent = overall.value);

  const form = document.getElementById('evalForm');
  form.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const name = document.getElementById('studentName').value.trim();
    if(!name){ alert('Vui lòng nhập tên hoặc mã sinh viên.'); return; }
    const comment = document.getElementById('comment').value.trim();
    const overallVal = document.getElementById('overall').value;
    const payload = {
      name,
      overall: Number(overallVal),
      comment,
      ratings: {}
    };
    ratings.forEach(r=> {
      const node = document.querySelector('.rating[data-name="'+r+'"]');
      payload.ratings[r] = Number(node.dataset.current || defaultStars);
    });
    try{
      const res = await fetch(apiBase + '/reviews', {
        method: 'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify(payload)
      });
      if(!res.ok) throw new Error('Server error');
      alert('Gửi đánh giá thành công ✅');
      form.reset();
      ratings.forEach(r=> setRating(r, defaultStars));
      overall.value = 8; overallVal.textContent = 8;
      loadDashboard();
    }catch(err){
      alert('Gửi thất bại: ' + err.message);
    }
  });

  document.getElementById('resetBtn').addEventListener('click', ()=>{
    if(confirm('Xóa nội dung đang nhập?')) {
      document.getElementById('evalForm').reset();
      ratings.forEach(r=> setRating(r, defaultStars));
      overall.value = 8; overallVal.textContent = 8;
    }
  });

  async function loadDashboard(){
    try{
      const res = await fetch(apiBase + '/reviews');
      const data = await res.json();
      document.getElementById('total').textContent = data.length;
      if(data.length===0){
        document.getElementById('avg').textContent='—';
        document.getElementById('recent').textContent='—';
      }else{
        const avg = (data.reduce((s,a)=> s + a.overall,0)/data.length).toFixed(2);
        document.getElementById('avg').textContent = avg;
        document.getElementById('recent').textContent = new Date(data[0].created_at).toLocaleString();
      }
      const rows = data.map((r,i)=> `<tr><td>${i+1}</td><td>${escapeHtml(r.name)}</td><td>${r.overall}</td><td title="${escapeHtml(r.comment)}">${escapeHtml(r.comment||'').slice(0,120)}</td><td>${new Date(r.created_at).toLocaleString()}</td></tr>`).join('');
      document.querySelector('#submissionsTable tbody').innerHTML = rows;
    }catch(err){
      console.error(err);
    }
  }
  function escapeHtml(str){return String(str||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
  document.getElementById('exportBtn').addEventListener('click', async ()=>{
    const res = await fetch(apiBase + '/reviews');
    const data = await res.json();
    if(data.length===0){ alert('Không có dữ liệu'); return; }
    const csv = toCSV(data);
    const blob = new Blob([csv], {type:'text/csv'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download='guide_metier_submissions.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
  });
  document.getElementById('clearAll').addEventListener('click', async ()=>{
    if(!confirm('Xóa tất cả dữ liệu?')) return;
    await fetch(apiBase + '/reviews', {method:'DELETE'});
    loadDashboard();
  });

  function toCSV(arr){
    const headers = ['id','name','overall','comment','created_at','progress','quality','teamwork','presentation'];
    const lines = [headers.join(',')];
    arr.forEach(a=>{
      const row = [
        a.id,
        '"'+(a.name||'').replace(/"/g,'""')+'"',
        a.overall,
        '"'+(a.comment||'').replace(/"/g,'""')+'"',
        a.created_at,
        a.ratings.progress,
        a.ratings.quality,
        a.ratings.teamwork,
        a.ratings.presentation
      ];
      lines.push(row.join(','));
    });
    return lines.join('\n');
  }

  // initial
  loadDashboard();
})();