// server.js - Express API for GuideMétier
const express = require('express');
const path = require('path');
const db = require('./db');
const app = express();
app.use(express.json());

// Serve static frontend (built static files)
app.use('/static', express.static(path.join(__dirname, 'static')));
app.get('/', (req, res)=> res.sendFile(path.join(__dirname, 'index.html')));

// API endpoints
app.post('/api/reviews', async (req, res)=>{
  try{
    const {name, overall, comment, ratings} = req.body;
    const result = await db.query(
      `INSERT INTO reviews (name, overall, comment, progress, quality, teamwork, presentation)
       VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
      [name, overall, comment, ratings.progress, ratings.quality, ratings.teamwork, ratings.presentation]
    );
    res.status(201).json(result.rows[0]);
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

app.get('/api/reviews', async (req, res)=>{
  try{
    const result = await db.query(`SELECT * FROM reviews ORDER BY created_at DESC`);
    res.json(result.rows);
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

app.delete('/api/reviews', async (req, res)=>{
  try{
    await db.query('TRUNCATE reviews RESTART IDENTITY');
    res.json({ok:true});
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

app.delete('/api/reviews/:id', async (req,res)=>{
  try{
    const id = req.params.id;
    await db.query('DELETE FROM reviews WHERE id=$1',[id]);
    res.json({ok:true});
  }catch(err){ console.error(err); res.status(500).json({error:'db error'}); }
});

// health
app.get('/health', (req,res)=> res.json({ok:true}));

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Server listening on', port));
