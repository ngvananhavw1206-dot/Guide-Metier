GuideMétier — Fullstack deployable project
Included:
- index.html (frontend)
- static/ (styles.css, app.js, logo image)
- server.js, db.js (Express backend)
- package.json
- Dockerfile, docker-compose.yml
- init.sql (DB schema)

**Logo image path (in this environment):**
/mnt/data/B82915CA-7C06-4FFF-812E-AD30097693C9.jpeg
(If you want to use it in production, add it to static/logo.jpeg in the repo. In this package it's already copied.)

## Run locally with Docker Compose (recommended)
1. Install Docker.
2. unzip the package and cd into folder.
3. Run:
   docker compose up --build
4. Open http://localhost:3000

## Deploy to Render (example)
1. Push this repo to GitHub.
2. Create a new Web Service on Render and connect to the GitHub repo.
3. Set the build command: docker build -t guide-metier .
   (or leave default: 'npm install && npm run build' if using different setup)
4. Add Environment variable: DATABASE_URL (Render Postgres add-on) or connect a managed Postgres.
5. Deploy.

## Deploy to Vercel + Railway (alternative)
- Frontend can be on Vercel (static) and Backend on Railway/Render with Postgres.
- Or deploy both with Docker on a single host.

## Notes / Next steps I can do for you (if you want me to finish deploy)
- Create GitHub repo and push code.
- Connect to Render and deploy automatically (you will need to authorize).
- Create managed Postgres on Railway (requires your account).
- Configure environment variables and TLS.

If you want, I can:
A) Create the GitHub repo + push (you must provide or authorize a GitHub token).  
B) Or provide step-by-step and you do the clicks (I will guide).

**Local static files & logo**
I included the provided image as static/logo.jpeg in the package. Source path used: /mnt/data/B82915CA-7C06-4FFF-812E-AD30097693C9.jpeg
